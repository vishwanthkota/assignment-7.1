package com.example.myapplication.triger;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //linking a button to the givinen activitty i.e web page
        Button openwebpage=(Button) findViewById(R.id.button2);
        //do other activity with other button
        //Button openactivity=(Button) findViewById(R.id.button);
        //given openWebPage linking with the
        openwebpage.setOnClickListener(this);
        //openactivity.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        //creating an intent i.e is webintent giving an URL for it
        //Action view for opening an web activity .there are many intent for every activy
        Intent webintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.co.in/"));
        Toast.makeText(getApplicationContext(),"opening web page",Toast.LENGTH_LONG).show();
        startActivity(webintent);

    }
    //public void onclick(View v)
    //{
        //Intent openintent= new Intent(Intent.ACTION_DIAL,("tel:9014333231"));
        //Toast.makeText(getApplicationContext(),"calling to vishwanth",Toast.LENGTH_LONG).show();
      //  startActivity(openintent);
    //}

}
